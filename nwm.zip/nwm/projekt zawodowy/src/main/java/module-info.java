module com.example.projektzawodowy {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.projektzawodowy to javafx.fxml;
    exports com.example.projektzawodowy;
}